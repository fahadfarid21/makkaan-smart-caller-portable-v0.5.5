// Opens a persistent native browser side panel. No network access or CRM writes here.
async function configurePanel() {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (error) {
    console.error('Makkaan Sidecar panel setup failed:', error);
  }
}
chrome.runtime.onInstalled.addListener(configurePanel);
chrome.runtime.onStartup.addListener(configurePanel);
configurePanel();
