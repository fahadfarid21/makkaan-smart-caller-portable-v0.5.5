(function (root) {
  'use strict';
  const finite = (v) => Number.isFinite(Number(v)) ? Number(v) : NaN;
  function price(area, rate) {
    area = finite(area); rate = finite(rate);
    if (!(area > 0) || !(rate > 0)) return { valid: false, area, rate, total: NaN };
    return { valid: true, area, rate, total: area * rate };
  }
  function paymentPlan(total, dpPct, installmentPct, possessionPct, months) {
    total = finite(total); dpPct = finite(dpPct); installmentPct = finite(installmentPct);
    possessionPct = finite(possessionPct); months = finite(months);
    const valuesValid = total >= 0 && [dpPct, installmentPct, possessionPct].every(v => Number.isFinite(v) && v >= 0 && v <= 100) && months > 0;
    if (!valuesValid) return { valid: false, percentagesValid: false, totalPercent: NaN, balancePct: NaN };
    const totalPercent = dpPct + installmentPct + possessionPct;
    const percentagesValid = Math.abs(totalPercent - 100) < 0.005;
    const downPayment = total * dpPct / 100;
    const installmentPool = total * installmentPct / 100;
    const possession = total * possessionPct / 100;
    return {
      valid: true, percentagesValid, totalPercent, balancePct: 100 - totalPercent,
      downPayment, installmentPool, possession, months,
      monthly: installmentPool / months,
      quarterly: installmentPool / (months / 3)
    };
  }
  function reverseRate(total, area) {
    total = finite(total); area = finite(area);
    if (!(total >= 0) || !(area > 0)) return { valid: false, rate: NaN };
    return { valid: true, rate: total / area };
  }
  function budgetArea(budget, rate) {
    budget = finite(budget); rate = finite(rate);
    if (!(budget >= 0) || !(rate > 0)) return { valid: false, area: NaN };
    return { valid: true, area: Math.floor(budget / rate), exactArea: budget / rate };
  }
  const api = { price, paymentPlan, reverseRate, budgetArea };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.MakkaanCalculator = api;
})(typeof window !== 'undefined' ? window : globalThis);
