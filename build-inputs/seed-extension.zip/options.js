const $ = (id) => document.getElementById(id);
function setStatus(text, kind = '') {
  $('status').textContent = text;
  $('status').className = `status ${kind}`.trim();
}

async function loadSettings() {
  try {
    const data = await chrome.storage.local.get(['geminiApiKey', 'geminiModel']);
    $('apiKey').value = data.geminiApiKey || '';
    $('model').value = data.geminiModel || 'gemini-3.5-flash-lite';
    setStatus(data.geminiApiKey ? 'A Gemini API key is stored in this browser profile.' : 'No Gemini API key configured. AI refinement is currently disabled.');
  } catch (e) {
    setStatus(`Could not load settings: ${e.message || e}`, 'bad');
  }
}

$('save').addEventListener('click', async () => {
  const apiKey = $('apiKey').value.trim();
  const model = $('model').value;
  if (apiKey && apiKey.length < 15) {
    setStatus('That key looks too short. Check the value and try again.', 'bad');
    return;
  }
  try {
    await chrome.storage.local.set({ geminiApiKey: apiKey, geminiModel: model });
    setStatus(apiKey ? `Saved locally. Model selected: ${model}. No test request was sent.` : 'API key removed. AI refinement is disabled.', 'good');
  } catch (e) {
    setStatus(`Could not save settings: ${e.message || e}`, 'bad');
  }
});

$('test').addEventListener('click', async () => {
  const apiKey = $('apiKey').value.trim();
  const model = $('model').value;
  if (!apiKey) {
    setStatus('Paste an API key first. No request was sent.', 'bad');
    return;
  }
  $('test').disabled = true;
  setStatus('Testing with a tiny generic test phrase. No CRM data is sent.');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: 'Rewrite this generic test phrase as a polite short sentence: call tomorrow.' }] }],
        generationConfig: { temperature: 0.1, maxOutputTokens: 80 }
      }),
      signal: controller.signal
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data?.error?.message || `HTTP ${response.status}`);
    const sample = (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join(' ').trim();
    if (!sample) throw new Error('The API response did not contain text.');
    await chrome.storage.local.set({ geminiApiKey: apiKey, geminiModel: model });
    setStatus(`Connection successful using ${model}. Test output: ${sample}`, 'good');
  } catch (e) {
    setStatus(`${e.name === 'AbortError' ? 'Test timed out.' : (e.message || String(e))}\nCheck the key, model availability, network connection, and free-tier quota.`, 'bad');
  } finally {
    clearTimeout(timeout);
    $('test').disabled = false;
  }
});

$('clear').addEventListener('click', async () => {
  if (!window.confirm('Remove the saved Gemini API key from this extension profile?')) return;
  try {
    await chrome.storage.local.remove(['geminiApiKey']);
    $('apiKey').value = '';
    setStatus('Saved API key removed. AI refinement is disabled.', 'good');
  } catch (e) {
    setStatus(`Could not remove the key: ${e.message || e}`, 'bad');
  }
});

loadSettings();
