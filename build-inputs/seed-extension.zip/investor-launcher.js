(() => {
  'use strict';
  const button = document.getElementById('investorModeLaunch');
  if (!button || button.dataset.ready === '1') return;
  button.dataset.ready = '1';

  function openPresentation() {
    try {
      const url = chrome.runtime.getURL('investor-mode.html');
      if (chrome.tabs && typeof chrome.tabs.create === 'function') {
        chrome.tabs.create({ url }, () => {
          if (chrome.runtime.lastError) window.open(url, '_blank', 'noopener');
        });
      } else {
        window.open(url, '_blank', 'noopener');
      }
    } catch (_) {
      button.textContent = 'Open page unavailable';
      button.disabled = true;
    }
  }

  button.addEventListener('click', openPresentation);
})();
