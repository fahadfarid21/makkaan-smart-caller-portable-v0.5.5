(function () {
  'use strict';

  const VERSION = '0.5.2';
  const styleId = 'makkaan-premium-shell-style-052';
  if (document.getElementById(styleId)) return;

  // Reverse common Windows-1252/UTF-8 mojibake without rewriting scripts or styles.
  const cp1252 = {
    '\u20ac': 0x80, '\u201a': 0x82, '\u0192': 0x83, '\u201e': 0x84,
    '\u2026': 0x85, '\u2020': 0x86, '\u2021': 0x87, '\u02c6': 0x88,
    '\u2030': 0x89, '\u0160': 0x8a, '\u2039': 0x8b, '\u0152': 0x8c,
    '\u017d': 0x8e, '\u2018': 0x91, '\u2019': 0x92, '\u201c': 0x93,
    '\u201d': 0x94, '\u2022': 0x95, '\u2013': 0x96, '\u2014': 0x97,
    '\u02dc': 0x98, '\u2122': 0x99, '\u0161': 0x9a, '\u203a': 0x9b,
    '\u0153': 0x9c, '\u017e': 0x9e, '\u0178': 0x9f
  };

  function decodeToken(token) {
    const bytes = [];
    for (const ch of token) {
      const cp = ch.codePointAt(0);
      if (cp <= 0xff) bytes.push(cp);
      else if (Object.prototype.hasOwnProperty.call(cp1252, ch)) bytes.push(cp1252[ch]);
      else return token;
    }
    try {
      const decoded = new TextDecoder('utf-8', { fatal: true }).decode(new Uint8Array(bytes));
      return decoded.includes('\ufffd') ? token : decoded;
    } catch (_) {
      return token;
    }
  }

  function repairText(value) {
    let out = String(value == null ? '' : value);
    // Limit each conversion to a suspicious marker and the short encoded sequence after it.
    out = out.replace(/(?:\u00c2|\u00c3|\u00e2)[^\s<>]{1,5}/g, decodeToken);
    out = out.replace(/(MAKKAAN\s*\/\s*SALES\s*SIDECAR)\s*0\.4\.4\b/ig, '$1 ' + VERSION);
    out = out.replace(/(FIELD\s+GUIDE\s*[\u00b7.\-]\s*VERSION)\s*0\.4\.4\b/ig, '$1 ' + VERSION);
    return out;
  }

  function repairDom(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentElement;
        if (!p || p.closest('script,style,noscript,textarea,code,pre')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      const fixed = repairText(node.nodeValue);
      if (fixed !== node.nodeValue) node.nodeValue = fixed;
    }
    const elements = root.querySelectorAll ? root.querySelectorAll('*') : [];
    for (const el of elements) {
      for (const attr of Array.from(el.attributes || [])) {
        if (!/^(value|placeholder|title|aria-label|aria-description|alt)$/i.test(attr.name)) continue;
        const fixed = repairText(attr.value);
        if (fixed !== attr.value) el.setAttribute(attr.name, fixed);
      }
    }
    if (document.title) document.title = repairText(document.title);
  }

  const css = `
    :root {
      --makk-ink: #182d3b;
      --makk-muted: #64747d;
      --makk-line: #e4ebe7;
      --makk-green: #236553;
      --makk-green-soft: #edf5f1;
      --makk-gold: #b7934e;
      --makk-paper: #ffffff;
      --makk-canvas: #f8faf9;
    }
    html { background: var(--makk-paper) !important; color: var(--makk-ink); font-size: 16px !important; }
    body { background: var(--makk-paper) !important; color: var(--makk-ink) !important; font-family: Inter, "Segoe UI", Arial, sans-serif !important; font-size: 14px !important; line-height: 1.5 !important; -webkit-font-smoothing: antialiased; }
    h1, h2, h3, .headline, .page-title, .brand-title { color: var(--makk-ink); letter-spacing: -.025em; }
    h1, .headline, .page-title { font-family: Georgia, "Times New Roman", serif !important; font-weight: 600; }
    header, .app-header, .topbar, .brand-bar, .brand-header { background: #fff !important; color: var(--makk-ink) !important; border-color: var(--makk-line) !important; }
    nav { gap: 5px; }
    .navbtn { cursor: pointer !important; background: #fff !important; color: #586a73 !important; border: 1px solid transparent !important; border-radius: 10px !important; font-size: 13px !important; padding: 9px 11px !important; font-weight: 650 !important; transition: background .16s ease, border-color .16s ease, color .16s ease, transform .16s ease; }
    .navbtn:hover { background: #f5f8f6 !important; border-color: var(--makk-line) !important; color: var(--makk-ink) !important; }
    .navbtn.active, .navbtn[aria-current="page"], .navbtn[aria-selected="true"] { background: var(--makk-green-soft) !important; border-color: #d5e5dc !important; color: var(--makk-green) !important; }
    button, .btn, [role="button"] { cursor: pointer; font-size: 13px !important; transition: background-color .16s ease, border-color .16s ease, color .16s ease, box-shadow .16s ease, transform .16s ease; }
    button:focus-visible, a:focus-visible, [role="button"]:focus-visible { outline: 3px solid rgba(35, 101, 83, .24) !important; outline-offset: 2px !important; }
    button:disabled, [role="button"][aria-disabled="true"] { cursor: not-allowed !important; opacity: .55 !important; }
    .card, .guide-card, .guide-step, .section-card, .quick-action-card, #investor-mode-shortcut { background: #fff !important; border-color: var(--makk-line) !important; box-shadow: 0 8px 24px rgba(24, 45, 59, .045) !important; }
    #investor-mode-shortcut { padding: 13px 14px !important; border-radius: 14px !important; border: 1px solid #dce8e2 !important; }
    #investor-mode-shortcut button, #investorModeLaunch { background: var(--makk-green) !important; color: #fff !important; border: 1px solid var(--makk-green) !important; border-radius: 9px !important; font-weight: 750 !important; }
    #investor-mode-shortcut button:hover, #investorModeLaunch:hover { background: #174d3f !important; transform: translateY(-1px); }
    .section-label, .overline, .eyebrow, .brand-overline { letter-spacing: .11em; }
    .guide-section ol, .guide-section ul, .field-guide ol, .field-guide ul { padding-left: 20px; }
    .guide-section li, .field-guide li { margin: 6px 0; font-size: 14px !important; line-height: 1.6 !important; }
    .shell-toast { position: fixed; z-index: 2147483647; bottom: 14px; left: 14px; right: 14px; padding: 10px 12px; border: 1px solid #dce8e2; border-radius: 11px; background: #fff; color: var(--makk-ink); box-shadow: 0 12px 30px rgba(24,45,59,.14); font: 13px/1.5 Inter, "Segoe UI", Arial, sans-serif; }
    @media (prefers-reduced-motion: reduce) { *, *::before, *::after { transition: none !important; scroll-behavior: auto !important; } }
  `;
  const style = document.createElement('style');
  style.id = styleId;
  style.textContent = css;
  document.head.appendChild(style);

  const guideContent = [
    {
      title: 'build a useful pre-call brief', tag: 'ol', items: [
        'Open the existing CRM record and confirm the prospect name, source, last status and most recent activity date.',
        'Review actual call notes, stated requirements, prior promises and unresolved questions before contacting the lead.',
        'Separate verified facts from assumptions. Note the unit type or floor, area, budget, timeline and intended use only when recorded or confirmed.',
        'Choose one purpose for this call and prepare two or three short discovery questions, not a long pitch.',
        'Keep the currently approved price sheet and next-step options ready. Verify price, availability and payment terms before quoting.'
      ]
    },
    {
      title: 'record the outcome correctly', tag: 'ul', items: [
        'Update lead quality and the permitted call status based on what the prospect actually said; do not infer interest.',
        'Record Activity Type as Call and set the next activity date only when a follow-up was agreed or is genuinely due.',
        'Add concise comments: requirement, budget comfort, timeline, objection, promised action and who owns the next step.',
        'Review the values before saving. Confirm the write and leave unrelated CRM fields untouched.'
      ]
    },
    {
      title: "what the sidecar won't do", tag: 'ul', items: [
        'It will not auto-dial, contact a prospect, or invent a conversation or CRM history.',
        'It will not confirm live inventory, approvals, discounts or prices without an approved source.',
        'It will not promise rent, profit, resale value, capital appreciation, completion dates or guaranteed returns.',
        'It will not make a CRM change on your behalf without your review and confirmation.'
      ]
    }
  ];

  function normalized(value) {
    return repairText(value).replace(/\s+/g, ' ').trim().toLowerCase();
  }
  function findHeading(phrase) {
    const preferred = Array.from(document.querySelectorAll('h1,h2,h3,h4,h5,h6,strong,b'));
    let found = preferred.find(el => normalized(el.textContent).includes(phrase));
    if (found) return found;
    return Array.from(document.querySelectorAll('p,div,span'))
      .filter(el => el.children.length === 0 && normalized(el.textContent).length < 100)
      .find(el => normalized(el.textContent).includes(phrase)) || null;
  }
  function isPlaceholder(text) {
    const t = normalized(text).replace(/[\u2013\u2014\u2022]/g, '-');
    return !t || /^[\d\s.)\-]+$/.test(t) || /^(todo|tbd|coming soon|n\/a)$/.test(t);
  }
  function comesBefore(a, b) {
    return !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
  }
  function listAfterHeading(heading, nextHeading) {
    return Array.from(document.querySelectorAll('ol,ul')).find(list => {
      if (!comesBefore(heading, list)) return false;
      if (nextHeading && !comesBefore(list, nextHeading)) return false;
      return true;
    }) || null;
  }
  function fillGuide() {
    for (const entry of guideContent) {
      const heading = findHeading(entry.title);
      if (!heading) continue;
      const nextEntry = guideContent
        .filter(x => x !== entry)
        .map(x => findHeading(x.title))
        .filter(Boolean)
        .filter(h => comesBefore(heading, h))
        .sort((a, b) => comesBefore(a, b) ? -1 : 1)[0] || null;
      let list = listAfterHeading(heading, nextEntry);
      if (!list) {
        list = document.createElement(entry.tag);
        list.className = 'makk-guide-list';
        heading.insertAdjacentElement('afterend', list);
      }
      const oldItems = Array.from(list.children).filter(el => el.tagName === 'LI');
      const replaceAll = oldItems.length === 0 || oldItems.every(li => isPlaceholder(li.textContent));
      if (replaceAll) {
        list.replaceChildren();
        for (const itemText of entry.items) {
          const li = document.createElement('li');
          li.textContent = itemText;
          list.appendChild(li);
        }
      } else {
        oldItems.forEach((li, i) => {
          if (isPlaceholder(li.textContent) && entry.items[i]) li.textContent = entry.items[i];
        });
      }
    }
  }

  const navSelectors = '.navbtn, button[data-view], [data-nav], button[aria-controls]';
  const navButtons = () => Array.from(document.querySelectorAll(navSelectors));
  function buttonLabel(el) { return normalized(el.innerText || el.textContent || '').replace(/[\u2197\u2192]/g, '').trim(); }
  function navFor(key) {
    const patterns = {
      queue: /\bqueue\b|lead queue/,
      brief: /\bbrief\b|pre.?call/,
      update: /\bupdate\b|call update/,
      calc: /\bcalc(?:ulator)?\b|price desk/,
      notes: /ai notes|\bnotes\b/,
      guide: /\bguide\b|field guide/,
      desk: /\bdesk\b|home|dashboard/,
      investor: /investor mode/
    };
    const rx = patterns[key];
    if (!rx) return null;
    return navButtons().find(el => rx.test(buttonLabel(el)) && !el.closest('#investor-mode-shortcut')) || null;
  }
  function viewTarget(key) {
    const candidates = Array.from(document.querySelectorAll('[id^="view-"], [data-panel], .view-panel'));
    const aliases = key === 'desk' ? ['desk', 'home', 'dashboard'] :
      key === 'brief' ? ['brief', 'pre-call', 'precall'] :
      key === 'notes' ? ['notes', 'ai-notes'] : [key];
    return candidates.find(el => {
      const id = normalized(el.id || el.getAttribute('data-panel') || '');
      return aliases.some(alias => id.includes(alias));
    }) || null;
  }
  function fallbackNavigate(key) {
    const candidates = Array.from(document.querySelectorAll('[id^="view-"], [data-panel], .view-panel'));
    const target = viewTarget(key);
    if (!target) return false;
    for (const panel of candidates) {
      const active = panel === target;
      panel.classList.toggle('active', active);
      if (active) panel.removeAttribute('hidden'); else panel.setAttribute('hidden', 'hidden');
    }
    const activeNav = navFor(key);
    if (activeNav) {
      navButtons().forEach(btn => btn.classList.toggle('active', btn === activeNav));
    }
    return true;
  }
  function keyForLabel(label) {
    if (/\bqueue\b/.test(label)) return 'queue';
    if (/\bbrief\b|pre.?call/.test(label)) return 'brief';
    if (/\bupdate\b/.test(label)) return 'update';
    if (/\bcalc(?:ulator)?\b|price desk/.test(label)) return 'calc';
    if (/ai notes|\bnotes\b/.test(label)) return 'notes';
    if (/\bguide\b/.test(label)) return 'guide';
    if (/\bdesk\b|home|dashboard/.test(label)) return 'desk';
    return null;
  }
  function wireNavFallback() {
    for (const nav of navButtons()) {
      if (nav.dataset.makkNavFallbackWired === '1') continue;
      const key = keyForLabel(buttonLabel(nav));
      if (!key) continue;
      nav.dataset.makkNavFallbackWired = '1';
      nav.addEventListener('click', () => {
        const target = viewTarget(key);
        if (!target) return;
        const isActive = target.classList.contains('active') && !target.hasAttribute('hidden');
        if (!isActive) fallbackNavigate(key);
      });
    }
  }
  function routeTo(key) {
    const nav = navFor(key);
    if (nav) { nav.click(); return true; }
    return fallbackNavigate(key);
  }
  function wireQuickActions() {
    const actions = [
      { test: /\bopen queue\b/, key: 'queue' },
      { test: /\bpre.?call brief\b/, key: 'brief' },
      { test: /\bcall update\b/, key: 'update' },
      { test: /\bopen calc(?:ulator)?\b|\bquick calc(?:ulator)?\b|\bquick price\b/, key: 'calc' },
      { test: /\bopen ai notes\b/, key: 'notes' },
      { test: /\bopen guide\b|\bfield guide\b/, key: 'guide' }
    ];
    for (const control of Array.from(document.querySelectorAll('button,a,[role="button"]'))) {
      if (control.dataset.makkShellActionWired === '1' || control.matches(navSelectors)) continue;
      if (control.closest('#investor-mode-shortcut')) continue;
      const label = buttonLabel(control);
      const action = actions.find(item => item.test.test(label));
      if (!action) continue;
      if (control.tagName === 'A' && control.getAttribute('href') && control.getAttribute('href') !== '#') continue;
      control.dataset.makkShellActionWired = '1';
      control.addEventListener('click', () => { routeTo(action.key); });
    }
  }

  function ensureInvestorLauncherFallback() {
    const button = document.getElementById('investorModeLaunch');
    if (!button || button.dataset.ready === '1' || button.dataset.shellFallbackReady === '1') return;
    button.dataset.shellFallbackReady = '1';
    button.addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: chrome.runtime.getURL('investor-mode.html') });
      } else if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
        window.open(chrome.runtime.getURL('investor-mode.html'), '_blank', 'noopener');
      }
    });
  }

  function run() {
    repairDom(document.body || document.documentElement);
    fillGuide();
    wireNavFallback();
    wireQuickActions();
    ensureInvestorLauncherFallback();
    document.title = 'Makkaan Sales Sidecar | v' + VERSION;
  }

  run();
  const observer = new MutationObserver(mutations => {
    let changedText = false;
    for (const mutation of mutations) {
      if (mutation.type === 'characterData') {
        const fixed = repairText(mutation.target.nodeValue);
        if (fixed !== mutation.target.nodeValue) mutation.target.nodeValue = fixed;
        changedText = true;
      } else if (mutation.type === 'childList') {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.TEXT_NODE) {
            const fixed = repairText(node.nodeValue);
            if (fixed !== node.nodeValue) node.nodeValue = fixed;
          } else if (node.nodeType === Node.ELEMENT_NODE && !node.matches('script,style')) {
            repairDom(node);
          }
        }
        changedText = true;
      }
    }
    if (changedText) {
      fillGuide();
      wireNavFallback();
      wireQuickActions();
      ensureInvestorLauncherFallback();
    }
  });
  observer.observe(document.documentElement, { subtree: true, childList: true, characterData: true });
})();
