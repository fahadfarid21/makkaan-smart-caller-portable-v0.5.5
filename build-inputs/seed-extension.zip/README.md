# Makkaan Sales Sidecar v0.4.4

A lightweight Chrome/Chromium side-panel helper for existing Makkaan lead records. Version 0.4.4 combines the existing CRM brief/update features with an editable fast property calculator.

## New in 0.4.4 — Calculator

- **Quick price:** enter area in sq ft and rate per sq ft; the total updates instantly.
- **Training rate presets:** Lower Ground Rs 65,000, Ground Rs 100,000, First Floor Rs 70,000, Fourth/Fifth Floor offices Rs 35,000. These are historical training anchors only; verify live approved rate and availability before quoting.
- **Editable payment plan:** change DP %, installment %, possession %, and duration in months. Calculates each amount, monthly installment, quarterly equivalent and flags allocations that do not total 100%.
- **Budget-to-area:** estimate whole square feet within a stated budget and rate.
- **Reverse rate:** calculate the effective per-square-foot rate from a total price and area.
- **Copy-ready calculation:** copy a concise client-facing breakdown. Nothing is sent automatically.
- Calculator inputs are stored in this Chrome extension profile only. The calculator does not write to the CRM or call an AI service.

## What changed in 0.4.3

- Targets `[data-doctype="Comment"] .content` for Lead Update comments and extracts only the `Comments` row from the tracked-field table.
- Targets `.timeline-item` for compact call, meeting, comment, and assignment signals.
- Targets `.open-tasks .single-activity` so open task records stay separate instead of being merged into page-wide UI text.
- Avoids treating generic CRM page chrome as useful timeline content. If a reliable snippet cannot be isolated, the brief falls back to advising a manual CRM check.

## Install/update

1. Extract the ZIP.
2. Run `Update-Existing-Extension.ps1` from the extracted folder. It backs up the existing unpacked extension before copying.
3. Open `chrome://extensions/` and click **Reload** on Makkaan Sales Sidecar.
4. Reload the open Makkaan lead tab.
5. Open **Calc** for calculations, or **Brief** → **Reload lead + context** → **Build quick brief offline** for a pre-call brief.

The updater defaults to the known extension folder under Downloads. If your active unpacked extension lives elsewhere, pass `-Destination "FULL\PATH\TO\makkaan-sales-sidecar-extension"`.

## Calculator use

Enter the unit area and current approved rate. Optionally choose a floor training preset, then edit every field as needed. Payment percentages must add to exactly 100% before you present the plan as balanced. Common template is 25% down payment + 65% installments + 10% possession over 36 months, but terms may vary by approved offer or unit.

## Notes and limitations

This is a local browser extension prototype, not an official CRM integration. The roster remains a snapshot; offline summaries use current visible form values and visible timeline containers. AI requests remain optional and should only be used with company-approved data handling. Confirm any task/date/history in the live CRM before acting. The extension does not auto-dial and requires review and confirmation for CRM writes. Calculations are arithmetic only and do not verify current inventory, contract terms, taxes, fees, discounts or any promised return.
