const $ = (id) => document.getElementById(id);
let activeTabId = null;
let currentLead = null;

function message(text, kind = '') {
  const el = $('message');
  el.textContent = text;
  el.className = `message ${kind}`.trim();
}

function aiMessage(text, kind = '') {
  const el = $('aiStatus');
  el.textContent = text;
  el.className = `ai-status ${kind}`.trim();
}

function setModeUI() {
  const quickNote = $('mode').value === 'note';
  $('status').disabled = quickNote;
  $('status').required = !quickNote;
  $('statusHint').textContent = quickNote
    ? 'Quick Note mode leaves Status unchanged.'
    : 'Required for a call update. Choose the real outcome.';
  if (quickNote) $('status').value = '';
}

async function getActiveLead() {
  message('Checking the active Makkaan tab…');
  $('save').disabled = true;
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  activeTabId = tab?.id ?? null;
  if (!tab || !tab.url || !/^https:\/\/prop-360\.com\/app\/lead\/CRM-LEAD-[^/?#]+/.test(tab.url)) {
    currentLead = null;
    $('leadId').textContent = 'No existing lead page detected';
    $('leadTitle').textContent = 'Open a lead detail page in this tab, then refresh.';
    message('This helper works only on an existing prop-360 lead detail page.', 'warn');
    return;
  }
  try {
    const data = await chrome.tabs.sendMessage(tab.id, { type: 'MAKKAAN_GET_LEAD' });
    if (!data?.ok) throw new Error(data?.error || 'Could not read lead form. Reload the CRM tab and retry.');
    currentLead = data.lead;
    $('leadId').textContent = currentLead.id;
    $('leadTitle').textContent = currentLead.title || 'Existing CRM record';
    $('save').disabled = false;
    message('Lead detected. Choose Call Update or Quick Note, then review before saving.', 'good');
  } catch (e) {
    currentLead = null;
    $('leadId').textContent = 'Could not inspect this page';
    $('leadTitle').textContent = '';
    message(`${e.message || e}. If this extension was just installed, reload the CRM tab and reopen the helper.`, 'bad');
  }
}

$('refresh').addEventListener('click', getActiveLead);
$('mode').addEventListener('change', setModeUI);
$('openAiSettings').addEventListener('click', () => chrome.runtime.openOptionsPage());

$('refine').addEventListener('click', async () => {
  const roughNote = $('comment').value.trim();
  if (!roughNote) {
    aiMessage('Type your rough note first, then choose Refine.', 'bad');
    $('comment').focus();
    return;
  }
  if (!$('aiConsent').checked) {
    aiMessage('Please confirm you are authorized to send this text to the configured external AI service. Do not include client-identifying or confidential data unless company policy permits it.', 'bad');
    return;
  }

  let config;
  try {
    config = await chrome.storage.local.get(['geminiApiKey', 'geminiModel']);
  } catch (e) {
    aiMessage('Could not read local AI settings. Open AI settings and configure the connection.', 'bad');
    return;
  }
  const apiKey = String(config.geminiApiKey || '').trim();
  const model = String(config.geminiModel || 'gemini-3.5-flash-lite').trim();
  if (!apiKey) {
    aiMessage('No Gemini API key configured. Open AI settings first.', 'bad');
    return;
  }
  if (!/^[a-zA-Z0-9._-]+$/.test(model)) {
    aiMessage('The configured model name is invalid. Open AI settings and choose a supported model ID.', 'bad');
    return;
  }

  const btn = $('refine');
  btn.disabled = true;
  $('useRefined').disabled = true;
  aiMessage('Refining only the rough note you typed…');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  try {
    const prompt = [
      'You are editing a short note for a real-estate sales CRM.',
      'Rewrite the user-supplied rough note into a concise, professional, factual CRM comment.',
      'Preserve the original meaning, language, names, dates, amounts, commitments, and uncertainty.',
      'Keep Roman Urdu in Roman Urdu if the note is mostly Roman Urdu; otherwise use the note\'s original language.',
      'Correct grammar, spelling, and clarity only. Do not invent facts, call outcomes, customer intent, dates, actions, or promises.',
      'Do not add a heading, quotation marks, analysis, or advice. Return only the refined note.',
      'If the note is ambiguous, keep the wording cautious instead of guessing.',
      '',
      'ROUGH NOTE:',
      roughNote
    ].join('\n');

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey
      },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.2, maxOutputTokens: 350 }
      }),
      signal: controller.signal
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const detail = data?.error?.message || `HTTP ${response.status}`;
      throw new Error(`Gemini request failed: ${detail}`);
    }
    const refined = (data?.candidates?.[0]?.content?.parts || [])
      .map(part => part.text || '')
      .join('\n')
      .trim();
    if (!refined) throw new Error('The model returned an empty draft. Try again or edit the note manually.');
    if (refined.length > 1500) throw new Error('The refined note is too long. Shorten the rough note and retry.');

    $('refinedNote').value = refined;
    $('useRefined').disabled = false;
    aiMessage('Draft ready. Review it carefully; nothing has been saved to the CRM.', 'good');
  } catch (e) {
    const text = e.name === 'AbortError'
      ? 'The AI request timed out. Check the connection and try again.'
      : (e.message || String(e));
    aiMessage(`${text}\nYour rough note is unchanged. You can edit it manually.`, 'bad');
  } finally {
    clearTimeout(timeout);
    btn.disabled = false;
  }
});

$('useRefined').addEventListener('click', () => {
  const refined = $('refinedNote').value.trim();
  if (!refined) return;
  $('comment').value = refined;
  $('comment').focus();
  aiMessage('Refined draft copied into Comments. Review or edit it before saving.', 'good');
});

$('updateForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!currentLead || activeTabId == null) {
    message('No existing lead detected. Refresh and select a CRM lead first.', 'bad');
    return;
  }
  const mode = $('mode').value;
  const status = $('status').value;
  const quality = $('quality').value;
  const nextDate = $('nextDate').value;
  const comment = $('comment').value.trim();

  if (mode === 'call' && !['Connected', 'Not Connected'].includes(status)) {
    message('Select the actual call result first.', 'warn');
    $('status').focus();
    return;
  }
  if (mode === 'note' && !comment && !nextDate && quality === '__KEEP__') {
    message('Quick Note needs a comment, a next activity date, or an explicit quality change.', 'warn');
    return;
  }

  const request = {
    type: 'MAKKAAN_PREVIEW_AND_SAVE',
    payload: {
      expectedLeadId: currentLead.id,
      mode,
      quality,
      status,
      activityType: 'Call',
      nextDate,
      comment
    }
  };
  const changes = [
    `Lead: ${currentLead.id}`,
    `Mode: ${mode === 'call' ? 'Call update' : 'Quick Note (Status unchanged)'}`,
    `Status: ${mode === 'call' ? status : 'leave unchanged'}`,
    `Activity Type: Call`,
    `Lead Quality: ${quality === '__KEEP__' ? 'leave unchanged' : quality}`,
    `Next Activity Date: ${nextDate || 'leave unchanged'}`,
    `Comment: ${comment ? 'append supplied note' : 'leave unchanged'}`,
    '',
    'Only the five approved fields are in scope. Confirm the lead and note are correct.'
  ].join('\n');
  if (!window.confirm(`Review CRM update\n\n${changes}\n\nSave these changes to the existing lead?`)) {
    message('Cancelled. No CRM changes were submitted.');
    return;
  }

  $('save').disabled = true;
  message('Applying approved fields and clicking Save…');
  try {
    const result = await chrome.tabs.sendMessage(activeTabId, request);
    if (!result?.ok) throw new Error(result?.error || 'The page did not confirm the update.');
    message(`${result.message}\n\nCheck the CRM confirmation before moving to another lead.`, result.verified ? 'good' : 'warn');
    if (result.verified) {
      $('status').value = '';
      $('quality').value = '__KEEP__';
      $('nextDate').value = '';
      $('comment').value = '';
      $('refinedNote').value = '';
      $('useRefined').disabled = true;
      $('mode').value = 'call';
      setModeUI();
      await getActiveLead();
      message(`${result.message}\nVerified save completed. The helper remains on this lead; open the next eligible lead when ready.`, 'good');
    }
  } catch (e) {
    message(`Update could not be confirmed: ${e.message || e}. Do not click Save repeatedly. Inspect the CRM record first.`, 'bad');
  } finally {
    $('save').disabled = false;
  }
});

setModeUI();
getActiveLead();
