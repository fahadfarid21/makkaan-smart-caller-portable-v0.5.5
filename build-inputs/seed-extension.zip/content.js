(() => {
  if (window.__makkaanSidecarLoaded) return;
  window.__makkaanSidecarLoaded = true;

  const leadIdFromUrl = () => {
    const m = location.pathname.match(/\/app\/lead\/(CRM-LEAD-[^/]+)\/?$/);
    return m ? m[1] : null;
  };

  function controlFor(fieldname) {
    const selectors = [
      `[data-fieldname="${fieldname}"]`,
      `.frappe-control[data-fieldname="${fieldname}"]`,
      `[data-fieldname="${fieldname}"] select`,
      `[data-fieldname="${fieldname}"] textarea`,
      `[data-fieldname="${fieldname}"] input`
    ];
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (!el) continue;
      if (el.matches('input,select,textarea')) return el;
      const nested = el.querySelector('input,select,textarea');
      if (nested) return nested;
    }
    return null;
  }

  function setNativeValue(el, value) {
    if (!el) throw new Error('A requested CRM field is missing from the form.');
    if (el.disabled || el.readOnly) throw new Error(`Field ${el.name || el.id || '(unnamed)'} is disabled or read-only.`);
    if (el.tagName === 'SELECT') {
      const option = [...el.options].find(o => o.value === value || o.text.trim() === value);
      if (!option) throw new Error(`The requested value '${value}' is not an available option in a CRM dropdown.`);
      el.value = option.value;
    } else {
      el.value = value;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  function fieldValue(fieldname) {
    const el = controlFor(fieldname);
    return el ? String(el.value ?? '') : null;
  }

  function dateForCRM(isoDate) {
    // Prefer the site's configured date format when this Frappe-style field exposes it.
    const fmt = window.frappe?.boot?.sysdefaults?.date_format || '';
    const [yyyy, mm, dd] = isoDate.split('-');
    const f = fmt.toLowerCase();
    if (f === 'dd-mm-yyyy' || f === 'dd-mm-yy') return `${dd}-${mm}-${yyyy}`;
    if (f === 'mm-dd-yyyy' || f === 'mm-dd-yy') return `${mm}-${dd}-${yyyy}`;
    if (f === 'dd/mm/yyyy') return `${dd}/${mm}/${yyyy}`;
    if (f === 'mm/dd/yyyy') return `${mm}/${dd}/${yyyy}`;
    return isoDate;
  }

  function isVisible(el) {
    return !!el && el.getClientRects().length > 0;
  }

  function collectRecentActivitySnippets() {
    // Use the exact structures confirmed on the Makkaan lead page:
    // .timeline-item/.timeline-content, [data-doctype="Comment"] .content,
    // and .open-tasks .single-activity. Never read broad page containers.
    const found = [];
    const seen = new Set();
    const normalizeText = value => String(value || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
    const visible = el => !!el && el.getClientRects().length > 0 &&
      getComputedStyle(el).visibility !== 'hidden' && getComputedStyle(el).display !== 'none';
    const uiNoise = /\b(?:Attach File|Shared With|Add a tag|Begin typing for results|Communication\s+All)\b/i;
    const isLeadUpdate = text => /Lead Update\s*#\s*\d+/i.test(text);
    const short = (text, max = 420) => {
      const s = normalizeText(text);
      if (s.length <= max) return s;
      return `${s.slice(0, max - 1).trimEnd()}…`;
    };
    const add = (type, raw, source = '') => {
      const text = normalizeText(raw);
      if (!text || text.length < 12 || uiNoise.test(text)) return;
      const key = `${type}:${text.toLowerCase().replace(/\s+/g, ' ').slice(0, 240)}`;
      if (seen.has(key)) return;
      seen.add(key);
      found.push({ type, text: short(text), source });
    };

    // Current CRM build renders tracked Lead Update records as Comment doctypes.
    // Parse only the Comments table row instead of including the whole field-change
    // table (which contains UI labels such as Activity Type and Next Activity Date).
    const commentNodes = [...document.querySelectorAll('[data-doctype="Comment"]')].filter(visible);
    for (const node of commentNodes) {
      const content = node.querySelector('.content') || node;
      if (!visible(content)) continue;
      const raw = String(content.innerText || content.textContent || '').trim();
      if (!raw || raw.length > 12000) continue;
      const heading = raw.split(/\r?\n/).map(s => s.trim()).find(line => /Lead Update\s*#\s*\d+/i.test(line)) || '';

      if (heading || isLeadUpdate(raw)) {
        let commentValue = '';
        const tables = [...content.querySelectorAll('table')];
        for (const table of tables) {
          for (const row of table.querySelectorAll('tr')) {
            const cells = [...row.querySelectorAll('th,td')]
              .map(cell => normalizeText(cell.innerText || cell.textContent || ''));
            if (cells.length >= 2 && /^comments\s*:?$/i.test(cells[0])) {
              commentValue = cells.slice(1).filter(Boolean).join(' | ');
            }
          }
        }
        // Some CRM renderings may not expose the tracked-field table as a native table.
        // In that case, do not dump the long aggregate; leave this update out and rely
        // on the live Comments field displayed separately in the brief.
        if (commentValue) {
          // Lead Update comments can be cumulative snapshots. Use a short tail to keep
          // recent context useful, while marking it as a snapshot rather than a new call.
          const tail = commentValue.length > 360 ? `…${commentValue.slice(-359)}` : commentValue;
          add('activity', `${heading || 'Lead Update'} · Comments snapshot: ${tail}`, 'comment-update');
        }
        continue;
      }

      // Ordinary comments without a tracked-field table are captured only when the
      // comment body itself is concise and doesn't look like a page-wide aggregate.
      const entry = node.closest('.timeline-item') || node;
      const entryText = normalizeText(entry.innerText || entry.textContent || '');
      if (entryText.length <= 500 && /\b(?:commented|added a comment|wrote)\b/i.test(entryText)) {
        add('activity', entryText, 'comment');
      }
    }

    // Compact timeline rows: extract short, recognizable call/meeting outcomes and
    // assignment events; skip long Lead Update containers because those are parsed above.
    const timelineItems = [...document.querySelectorAll('.timeline-item')].filter(visible);
    for (const item of timelineItems) {
      const text = normalizeText(item.innerText || item.textContent || '');
      if (!text || text.length > 380 || isLeadUpdate(text) || uiNoise.test(text)) continue;
      const recognizable = /\b(?:Call\s*(?:Connected|Not Connected)|Meeting\s*(?:Connected|Not Connected)|assigned|created this|edited this|commented)\b/i.test(text);
      if (!recognizable) continue;
      add('activity', text, 'timeline');
      if (found.filter(item => item.type === 'activity').length >= 4) break;
    }

    // The live page has two .open-tasks .single-activity rows per the read-only
    // diagnostic. Keep each task separate so the title/date are not mixed across tasks.
    const taskRows = [...document.querySelectorAll('.open-tasks .single-activity')].filter(visible);
    for (const row of taskRows) {
      const link = row.querySelector('a[href*="/app/todo/"]');
      if (!link) continue;
      const text = normalizeText(row.innerText || row.textContent || '');
      if (!text || text.length > 300 || uiNoise.test(text)) continue;
      add('task', `Open task: ${text.replace(/\bOpen Task\b/gi, '').trim()}`, 'open-task-row');
      if (found.filter(item => item.type === 'task').length >= 3) break;
    }

    // Timeline order on this CRM page is newest-first. Keep at most four activity
    // snippets and three task snippets, prioritizing the most recent visible items.
    const activities = found.filter(item => item.type === 'activity').slice(0, 4);
    const tasks = found.filter(item => item.type === 'task').slice(0, 3);
    return [...activities, ...tasks].slice(0, 6);
  }

  function getLeadInfo() {
    const id = leadIdFromUrl();
    if (!id) throw new Error('This is not an existing CRM lead detail URL.');
    const fields = ['internal_status', 'status', 'event_category', 'starts_on', 'description'];
    for (const f of fields) {
      if (!controlFor(f)) throw new Error(`Required form control '${f}' was not found. Nothing was changed.`);
    }
    return {
      id,
      title: (document.querySelector('h1')?.innerText || document.title || '').trim(),
      current: {
        quality: fieldValue('internal_status'),
        status: fieldValue('status'),
        activityType: fieldValue('event_category'),
        nextDate: fieldValue('starts_on'),
        comments: fieldValue('description')
      },
      recentActivities: collectRecentActivitySnippets()
    };
  }

  async function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  async function applyAndSave(payload) {
    const before = getLeadInfo();
    if (before.id !== payload.expectedLeadId) {
      throw new Error(`Lead mismatch. Expected ${payload.expectedLeadId}, current page is ${before.id}. Nothing changed.`);
    }
    const mode = payload.mode === 'note' ? 'note' : 'call';
    if (mode === 'call' && !['Connected', 'Not Connected'].includes(payload.status)) {
      throw new Error('Call outcome must be Connected or Not Connected. Nothing changed.');
    }
    if (mode === 'note' && !String(payload.comment || '').trim() && !String(payload.nextDate || '').trim() && payload.quality === '__KEEP__') {
      throw new Error('Quick Note needs a comment, a next activity date, or an explicit quality change. Nothing changed.');
    }
    if (payload.activityType !== 'Call') throw new Error('Activity Type is restricted to Call.');

    // Check all requested choices are valid before editing any field.
    if (payload.quality !== '__KEEP__') {
      const quality = controlFor('internal_status');
      if (![...quality.options].some(o => o.value === payload.quality || o.text.trim() === payload.quality)) {
        throw new Error(`Lead Quality option '${payload.quality}' is not available. Nothing changed.`);
      }
    }
    const statusControl = controlFor('status');
    if (mode === 'call' && ![...statusControl.options].some(o => o.value === payload.status || o.text.trim() === payload.status)) {
      throw new Error(`Status option '${payload.status}' is not available. Nothing changed.`);
    }
    const typeControl = controlFor('event_category');
    if (![...typeControl.options].some(o => o.value === 'Call' || o.text.trim() === 'Call')) {
      throw new Error('The Activity Type dropdown does not offer Call. Nothing changed.');
    }

    const desc = controlFor('description');
    const note = String(payload.comment || '').trim();
    const oldComment = String(desc.value || '');
    const newComment = note ? (oldComment.trim() ? `${oldComment.replace(/\s+$/, '')}\n${new Date().toLocaleString()} — ${note}` : `${new Date().toLocaleString()} — ${note}`) : null;

    // Only the five authorized fields below are changed.
    if (payload.quality !== '__KEEP__') setNativeValue(controlFor('internal_status'), payload.quality);
    if (mode === 'call') setNativeValue(controlFor('status'), payload.status);
    setNativeValue(controlFor('event_category'), 'Call');
    if (payload.nextDate) setNativeValue(controlFor('starts_on'), dateForCRM(payload.nextDate));
    if (newComment !== null) setNativeValue(desc, newComment);

    const changed = {
      quality: payload.quality === '__KEEP__' ? before.current.quality : fieldValue('internal_status'),
      status: mode === 'call' ? fieldValue('status') : before.current.status,
      activityType: fieldValue('event_category'),
      nextDate: fieldValue('starts_on'),
      comments: fieldValue('description')
    };
    if ((mode === 'call' && changed.status !== payload.status) || (mode === 'note' && changed.status !== before.current.status) || changed.activityType !== 'Call') {
      throw new Error('Field verification failed before Save. The form was not submitted; inspect the page before proceeding.');
    }
    if (payload.quality !== '__KEEP__' && changed.quality !== payload.quality) {
      throw new Error('Lead Quality did not match the selected option before Save. The form was not submitted.');
    }
    if (payload.nextDate && changed.nextDate !== dateForCRM(payload.nextDate) && changed.nextDate !== payload.nextDate) {
      throw new Error('Next Activity Date did not match the requested date before Save. The form was not submitted.');
    }
    if (note && changed.comments !== newComment) throw new Error('Comment did not match the appended note before Save. The form was not submitted.');

    const saveButton = [...document.querySelectorAll('button, input[type="submit"]')].find(el =>
      isVisible(el) && !el.disabled && (String(el.innerText || el.value || '').trim() === 'Save') &&
      (el.classList.contains('btn-primary') || el.matches('input[type="submit"]'))
    );
    if (!saveButton) throw new Error('The visible primary Save button was not found. Fields are filled but not submitted. Inspect the page; do not click blindly.');

    saveButton.click();
    // Wait for the application's save response/toast. Never claim success merely because the click occurred.
    let sawSaveSignal = false;
    for (let i = 0; i < 24; i++) {
      await wait(500);
      const text = (document.body?.innerText || '').toLowerCase();
      const toast = [...document.querySelectorAll('.alert, .toast, .msgprint, .indicator-pill, [role="alert"]')]
        .filter(isVisible).map(el => (el.innerText || '').trim()).join(' ').toLowerCase();
      const busy = [...document.querySelectorAll('button.btn-primary')].some(b => isVisible(b) && (b.disabled || /saving/i.test(b.innerText || '')));
      if (/saved successfully|changes saved|document saved|saved/i.test(`${toast} ${text}`) && !busy) {
        sawSaveSignal = true;
        break;
      }
    }

    const afterId = leadIdFromUrl();
    const after = {
      status: fieldValue('status'),
      activityType: fieldValue('event_category'),
      quality: fieldValue('internal_status'),
      nextDate: fieldValue('starts_on'),
      comments: fieldValue('description')
    };
    if (afterId !== before.id) throw new Error('The page navigated away during save. Inspect the CRM record manually before proceeding.');
    if (after.status !== changed.status || after.activityType !== changed.activityType || after.quality !== changed.quality || after.nextDate !== changed.nextDate || after.comments !== changed.comments) {
      throw new Error('The values changed after Save. Could not verify the saved state; inspect this record manually before trying again.');
    }

    return {
      ok: true,
      verified: sawSaveSignal,
      message: sawSaveSignal
        ? `CRM reported a save for ${before.id}. ${mode === 'note' ? 'Status was left unchanged.' : `Status set to ${changed.status}.`} Form fields still match the submitted values; confirm the record before moving on.`
        : `Save was clicked for ${before.id}, and the form still shows the submitted values, but no clear save confirmation was detected. Verify the record manually before retrying.`,
      leadId: before.id
    };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !['MAKKAAN_GET_LEAD', 'MAKKAAN_PREVIEW_AND_SAVE'].includes(msg.type)) return;
    try {
      if (msg.type === 'MAKKAAN_GET_LEAD') {
        sendResponse({ ok: true, lead: getLeadInfo() });
      } else {
        applyAndSave(msg.payload).then(sendResponse).catch(err => sendResponse({ ok: false, error: err.message || String(err) }));
        return true;
      }
    } catch (err) {
      sendResponse({ ok: false, error: err.message || String(err) });
    }
  });
})();
